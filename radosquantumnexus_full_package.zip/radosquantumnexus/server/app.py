from flask import Flask, jsonify
from qiskit import QuantumCircuit, Aer, execute

app = Flask(__name__)

@app.route('/')
def home():
    return jsonify({"message": "Welcome to RADOS Quantum Nexus API"})

@app.route('/quantum-test')
def quantum_test():
    # Create a simple quantum circuit
    circuit = QuantumCircuit(2, 2)
    circuit.h(0)
    circuit.cx(0, 1)
    circuit.measure([0,1], [0,1])

    simulator = Aer.get_backend('qasm_simulator')
    job = execute(circuit, simulator, shots=1000)
    result = job.result()
    counts = result.get_counts(circuit)
    return jsonify({"quantum_result": counts})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)