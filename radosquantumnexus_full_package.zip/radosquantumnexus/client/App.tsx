import React from 'react';

export default function App() {
  return (
    <div className="p-8">
      <h1 className="text-3xl font-bold mb-4">RADOS Quantum Nexus Client</h1>
      <p>Welcome to the cutting-edge quantum computing frontend.</p>
    </div>
  );
}