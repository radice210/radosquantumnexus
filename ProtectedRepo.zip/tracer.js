// Silent tracker script (demo version)
console.log("Tracker activated - unauthorized access will be reported.");
